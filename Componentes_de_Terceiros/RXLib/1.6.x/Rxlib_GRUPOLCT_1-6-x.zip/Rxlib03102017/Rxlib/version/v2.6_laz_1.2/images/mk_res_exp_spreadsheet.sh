rm rxdbgridexportspreadsheet.res
/usr/local/share/lazarus/tools/lazres rxdbgridexportspreadsheet.res TRxDBGridExportSpreadSheet.png
