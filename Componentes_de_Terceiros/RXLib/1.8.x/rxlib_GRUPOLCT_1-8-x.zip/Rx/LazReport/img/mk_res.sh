rm lrrxdbdialogcontrols_img.inc
rm lrrxdbdialogcontrols_img.res

/usr/local/share/lazarus/tools/lazres lrrxdbdialogcontrols_img.res TlrRxDBLookupComboBox.bmp TlrRxDateEdit.bmp TlrSelectPeriodControl.bmp TRxLazReport.png
