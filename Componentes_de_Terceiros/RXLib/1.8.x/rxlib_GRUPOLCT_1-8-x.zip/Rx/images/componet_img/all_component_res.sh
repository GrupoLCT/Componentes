rm tooledit.lrs
rm rxdbgrid.lrs
rm tooledit.res
rm rxdbgrid.res
rm pickdate.rex

/usr/local/share/lazarus/tools/lazres rxdbgrid.res rx_markerdown.png rx_markerup.png rx_DropDown.png  rx_Ellipsis.png  rx_Glyph.png  rx_minus.png  rx_plus.png  rx_UpDown.png rx_menu_grid.png

/usr/local/share/lazarus/tools/lazres rx_lcl.res picDateEdit.png rxbtn_downarrow.png rx_range_h_back.png rx_range_h_sel.png rx_slader_bottom.png rx_slader_top.png rx_range_v_back.png rx_range_v_sel.png rx_slader_left.png rx_slader_right.png

/usr/local/share/lazarus/tools/lazres pickdate.res rx_next1.png rx_next2.png rx_prev1.png rx_prev2.png

#../../../../tools\lazres.exe tooledit.lrs picDateEdit.bmp
#../../../../tools\lazres.exe rxdbgrid.lrs rx_markerdown.xpm rx_markerup.xpm
